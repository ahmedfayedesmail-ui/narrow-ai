"""NARROW: safety-first task continuity for AI agents."""

__version__ = "0.4.0"
