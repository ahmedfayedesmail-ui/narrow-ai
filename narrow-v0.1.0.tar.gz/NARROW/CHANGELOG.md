# Changelog

## 0.1.0 — Initial safety-first foundation

- Local SQLite task journal and resumable Markdown handoff.
- Independent full Git copy per task, with remotes removed.
- Explicit path allowlist and denylist.
- Agent CLI process wrapper and repository-state monitor.
- Configured verification commands with interactive approval.
- Snapshot-bound verification results and human acceptance gate.
- Bounded generic agent → verification → repair loop with compact handoff context.
- Refuse automatic repair if verification mutates the workspace.
- NARROW-managed Git calls remove inherited Git redirection/config variables, disable system/global config and fsmonitor, and skip initial Git LFS smudge downloads.
- Reject external symlinks and hard-linked workspace files before, during, and after agent execution.
- Bound verification output capture and terminate verification process groups on timeout (best effort).
- Add final safety scans and require an unmodified authoritative task contract before completion.
- Threat model, safety model, architecture, and usage documentation.
