# Threat Model

## Trust boundaries

- **User:** chooses the task, scope, agent, verification commands, and acceptance evidence.
- **NARROW CLI:** trusted to create task metadata, supervise the launched process, record state, and apply completion gates.
- **AI agent:** untrusted with respect to correctness; it may misunderstand the request, over-edit, stop early, or attempt unsafe commands.
- **Repository content:** untrusted input. Build scripts, test scripts, hooks, package managers, and project instructions may execute code.
- **External services:** outside NARROW's control. Agent CLIs may transmit prompts or repository content according to their own provider settings.

## Threats and mitigations

| Threat | v0.1 mitigation | Residual risk |
|---|---|---|
| Agent edits wrong project files | Separate workspace, strict path allowlist, live and final scans, refusal of pre-existing external symlinks/hard links | Absolute-path writes and link races remain possible without an OS sandbox |
| User's uncommitted work is overwritten | Refuse dirty original checkout; agent does not run there | External commands may still access the original path |
| Agent commits or switches branches | Detect changed task `HEAD`; stop and block finish | A commit may already exist on the isolated task branch |
| Agent says “done” with failing tests | Completion requires configured checks and human acceptance | Tests can be incomplete or incorrect |
| Stale test result after later edits | Check results bound to snapshot hash | Files outside the tracked/untracked scan may be missed in unusual setups |
| Lost context between sessions | Local append-only journal and Markdown handoff | Unrecorded decisions from chat are not recoverable |
| Secret pasted into notes | Common-pattern redaction | Redaction is heuristic; never paste secrets |
| Dangerous check command | Explicit config, command shown, interactive confirmation, no shell | The command still has user permissions and can have side effects |
| Agent runs indefinitely | Run timeout and process-group stop | Detached or escaped processes may survive |
| Checkout triggers a configured Git hook/filter | NARROW-managed Git calls disable system/global config, inherited Git redirection, and fsmonitor; initial clone skips Git LFS smudge | Local repository filters and arbitrary non-Git build scripts remain a trust boundary; agent commands are not OS-sandboxed |
| NARROW metadata path is redirected | Refuse symbolic links/hard links for sensitive metadata files; atomically replace NARROW-owned helper files | Host filesystem, parent directories, and same-user races are still trusted |
| Monitor fails | Stop the supervised run when repository checks fail | OS/process races remain possible |

## Out of scope for v0.1

- Defending against a fully malicious local user or a compromised OS.
- Sandboxing arbitrary build scripts or agent commands.
- Guaranteeing process-tree containment on every platform.
- Preventing arbitrary absolute-path writes or network access without the future OS-level sandbox.
- Proving that an agent has not exfiltrated data.
- Automatically merging or deploying changes.
- Provider-specific guarantees about model context, memory, or tool execution.

## Future hardening gates

Before advertising NARROW as safe for unattended autonomous execution, require:

1. Disposable container/VM runner with explicit mount and network policy.
2. Per-provider adapters with tested permission-mode detection.
3. Structured tool-event observation, not filesystem polling alone.
4. Bounded retry budgets, wall-clock budgets, and human escalation rules.
5. Cross-platform process-tree tests and fault injection.
6. Secret-handling review and redaction tests.
7. Independent security review and documented known limitations.
