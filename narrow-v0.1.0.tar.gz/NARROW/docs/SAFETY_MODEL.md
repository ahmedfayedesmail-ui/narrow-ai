# Safety Model

NARROW's primary product promise is **not making a user's work less safe**. The default behavior should be conservative, observable, reversible, and honest about uncertainty.

## Protected assets

- The user's original working tree and current branch.
- Uncommitted user work.
- Source code, local data, credentials, and environment variables.
- Correctness and integrity of the task result.
- The user's ability to inspect and decide before integrating changes.

## Non-negotiable invariants

1. Never start a task when the original checkout is dirty.
2. Never run the agent in the original checkout.
3. Never create an implicit unrestricted allowlist.
4. Never commit, merge, push, deploy, publish, or change remotes automatically.
5. Never call a task verified solely because an agent process exits with code 0 or says it is done.
6. Never call checks “passed” unless they ran successfully on the exact current snapshot.
7. Never hide failed checks, scope violations, monitor failures, or unresolved blockers.
8. Never silently enable agent permission-bypass flags.
9. Keep task notes and verification output local; do not send them to a NARROW service.
10. If NARROW cannot observe a safety-critical condition, fail closed and ask for review.

## v0.1 protections

- Separate full Git copy, independent Git metadata, and no configured remotes.
- Clean-baseline requirement.
- Required allowlist and optional denylist.
- Process wrapper with periodic scope and repository-state checks.
- Best-effort process-group termination on detected violations and command timeouts; check output is streamed with a 64 KiB retained tail.
- Refusal of symlinks resolving outside the task workspace and hard-linked regular files, with preflight, live, and final scans.
- NARROW-managed Git calls ignore inherited Git redirection variables and system/global config, and disable repository fsmonitor hooks.
- No shell interpolation for command execution.
- Explicit user confirmation for verification commands.
- Snapshot hashes that invalidate stale test results after edits.
- Human confirmation with evidence for every acceptance criterion.
- Bounded repair loop (1–5 attempts); passing checks stop at `READY_FOR_REVIEW`.
- Initial clone/checkout disables system/global Git configuration and Git LFS smudge downloads to reduce hook/filter side effects.
- Refuse to follow a symbolic link for `.narrow/`, its state database, or the repository-local Git exclude file.
- Fingerprint the NARROW-owned task, handoff, and execution-prompt files and stop if an agent edits or removes them.

## Known limitations

A workspace is not an OS-level sandbox. A child process can still access any path and service permitted to the current user. A malicious or misconfigured agent may edit an absolute path outside the workspace, access the network, read environment secrets, start detached processes, or continue work after the wrapper exits. Polling is not instantaneous and can detect a violation only after it begins. A process can write to an absolute path, open a network connection, create and use a link between scans, or launch a detached/escaped process. Process-tree termination is best-effort across operating systems.

For untrusted repositories, agents, commands, or generated code, use a disposable VM or a container with read-only mounts, no host credentials, restricted network, and explicit resource limits. NARROW v0.1 does not provision that sandbox. The Git configuration isolation applies to the initial copy/checkout only; it does not constrain arbitrary shell, Python, package-manager, browser, or network activity launched by an agent or check.

## Safe use guidance

- Keep the AI provider's own approval prompts enabled.
- Do not pass permission-bypass flags.
- Start with narrow allowed paths.
- Do not put secrets in task goals, notes, decisions, or acceptance evidence.
- Configure only test commands you understand.
- Review `narrow inspect` and the actual diff before integration.
- Treat every agent-created file, command, and test as untrusted until reviewed.
- Manually cherry-pick or merge only after review.

## Completion semantics

`VERIFIED_COMPLETE` is deliberately narrow. It means configured checks passed for the exact current snapshot, acceptance criteria were explicitly confirmed by a human, task scope checks passed, and the original checkout remained unchanged. It does **not** mathematically prove correctness, security, performance, or absence of defects. Those claims require appropriate domain-specific tests and review.
