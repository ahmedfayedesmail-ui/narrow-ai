# Roadmap

The roadmap is deliberately gated by safety evidence. A milestone is not complete because a demo looks good; it must pass its stated tests and failure scenarios.

## v0.1 — Safety-first foundation (implemented)

- Local task contract and SQLite event journal.
- Separate full Git copy per task, with remotes removed.
- Explicit path allowlist and denylist.
- CLI agent wrapper with process monitoring and bounded runtime.
- Provider-neutral handoff and manual resume.
- Explicitly approved verification commands.
- Snapshot-bound checks and human acceptance gate.
- Bounded generic agent → checks → repair cycle (maximum five attempts).
- Safety model and threat model.

## v0.2 — Reliable provider adapters

- Formal adapter protocol.
- Claude Code adapter and Codex CLI adapter, each tested against supported versions.
- Inject task and handoff context without disabling provider approvals.
- Capture structured task progress, tool outcomes, errors, and session exits where the provider exposes them.
- Detect unsupported or permission-bypassing modes and stop with a clear message.
- Adapter conformance test suite using fake agents.

**Exit gate:** session start/resume works without manual transcript copying; cancellation and failure preserve the journal; no provider adapter can silently weaken approval controls.

## v0.3 — Deeper Completion Intelligence

- Explicit task state machine and dependency graph.
- Dependency-aware check selection, followed by full required verification before completion.
- Evidence-linked failure classification and repair proposals.
- Stronger time, process, and command budgets across multi-agent task plans.
- Automatic escalation on repeated failure, scope expansion, missing permissions, destructive operations, or ambiguous requirements.
- “Blocked” is a valid terminal outcome; never fabricate success.

**Exit gate:** fault-injection tests prove that loops stop at every configured budget, stale evidence is invalidated, and all external/destructive actions require explicit authorization.

## v0.4 — Stronger execution isolation

- Optional disposable Docker/Podman sandbox.
- Read-only source mounts where possible, writable task workspace only.
- Explicit network allow/deny policy.
- No host credentials mounted by default.
- CPU, memory, process, and wall-clock limits.
- Safe dependency cache strategy.
- Cross-platform containment tests.

**Exit gate:** independent review of container boundaries and tests demonstrating that agent processes cannot modify the original checkout or access denied host paths under the supported configuration.

## v0.5 — Task Control Center

- Local web dashboard for active tasks, progress, decisions, scope alerts, checks, and evidence.
- Task timeline and side-by-side expected-vs-actual changes.
- Mobile-friendly read-only monitoring view.
- Exportable work receipt.
- No cloud account required for local use.

**Exit gate:** accessibility, local security, and performance review.

## v1.0 — Public stable release

- Documented support matrix.
- Reproducible builds and signed releases.
- Security contact and vulnerability response process.
- Migration/backward-compatibility policy for local state.
- Independent security review of autonomous execution path.
- Clear guarantee matrix distinguishing verified behavior from best-effort monitoring.
