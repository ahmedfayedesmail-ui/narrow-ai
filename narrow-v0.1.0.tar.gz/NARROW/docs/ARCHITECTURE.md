# NARROW Architecture (v0.1)

## Product model

NARROW owns the **task lifecycle**, not the intelligence of the model. The model proposes and edits; NARROW records intent, isolates repository work, watches observable boundaries, preserves task memory, and gates claims of completion.

```text
User intent
   |
   v
Task Contract -----> Local Event Journal <----- Decisions / Notes
   |
   v
Isolated Git Copy
   |
   +---- Configured Agent Command
   |          |
   |          v
   |     Filesystem / Git changes
   |          |
   +---- Scope + Base-Checkout Monitor
              |
              v
     Compact Task Handoff
              |
              v
     Bounded Repair Controller
              |
              v
   Configured Verification Commands
              |
              v
      Snapshot-bound Check Results
              |
              v
     Acceptance Confirmation
              |
              v
       VERIFIED_COMPLETE
```

## Components

### Task Contract

A task has a title, goal, explicit allowed path patterns, optional denied patterns, and one or more acceptance criteria. A task starts only from a clean original working tree. The current `HEAD` SHA is stored as the baseline.

### Isolation Manager

Each task gets a full local Git copy under the user's cache directory, a task branch inside that copy, and no configured remotes. The copy has an independent `.git` directory and object database; it does not share refs or configuration with the source repository. NARROW-managed Git calls strip inherited Git redirection variables, disable system/global configuration and fsmonitor, and the initial checkout skips Git LFS smudge downloads. LFS objects may need manual provisioning. NARROW rejects workspace symlinks that resolve outside the copy, hard-linked regular files, and special filesystem entries at task boundaries; live monitoring inspects changed paths. The original checkout is never used as the agent's working directory. NARROW does not merge the result.

### Scope Monitor

While the agent process is running, NARROW polls:

- changed tracked, untracked, and ignored paths relative to task `HEAD`;
- immutable fingerprints of NARROW-owned task, handoff, and prompt files;
- allowed and denied path patterns;
- original checkout `HEAD` and clean/dirty status;
- task workspace `HEAD` and branch;
- run duration and maximum changed-file count.

Out-of-scope or denied changes always stop the supervised process group. A final scan catches short-lived agents that exit before a polling cycle. This is best-effort process control, not a sandbox.

### Secondhand Memory

An append-only SQLite event journal records task creation, notes, decisions, agent lifecycle, scope events, and check results. `handoff` compiles the latest state into a portable Markdown packet. The packet is provider-neutral and intentionally avoids storing full chat transcripts.

### Verification Engine

Only named checks in `.narrow/config.json` can run. Each check is an argv array (not a shell string), is shown to the user, and requires interactive approval unless `--yes` is explicitly used. The `drive` command applies a configured generic agent command and re-runs checks after failure for a maximum of five attempts. Check output is incorporated into the next compact repair prompt. Any workspace mutation during verification stops the loop.

The engine hashes the changed workspace snapshot before and after a check. A check that mutates the workspace is not accepted as a successful verification. Successful results are bound to the exact snapshot hash they tested.

### Completion Gate

`finish` checks:

1. No denied or out-of-scope paths remain.
2. The task workspace is still on the task branch and baseline `HEAD` (agent-created commits are not accepted in v0.1).
3. The original checkout is still unchanged and clean.
4. The authoritative task brief is intact and no unsafe filesystem links remain.
5. Every configured check passed against the current workspace snapshot.
6. Every acceptance criterion has explicit human confirmation and evidence.

The `drive` command alone never writes `VERIFIED_COMPLETE`; after checks pass it writes `READY_FOR_REVIEW`. Only the separate human acceptance and `finish` gate can write `VERIFIED_COMPLETE`.

## Storage

- `.narrow/state.sqlite3` — task and event state.
- `.narrow/config.json` — local verification configuration.
- `.narrow/handoffs/` — optional exported handoffs (created only when requested).
- User cache `.../narrow/worktrees/<repo-hash>/<task-id>/` — independent task repository copies (the internal database field retains the historical name `worktree`).

`.narrow/` and the task helper files are excluded through local Git exclude rules, not committed into user source repositories.

## Planned adapter boundary

Future providers will implement an adapter contract with operations equivalent to:

- `start(task_contract, handoff, workspace)`
- `send_instruction(message)`
- `observe_event()`
- `interrupt(reason)`
- `resume(handoff)`
- `close()`

Adapters must expose provider capability and permission mode. NARROW must never silently switch an agent into an approval-bypass mode. Unsupported provider behavior must be surfaced as unsupported, not guessed.
