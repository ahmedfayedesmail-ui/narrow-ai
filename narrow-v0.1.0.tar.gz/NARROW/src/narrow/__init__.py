"""NARROW: safety-first task continuity for AI agents."""

__version__ = "0.1.0"
