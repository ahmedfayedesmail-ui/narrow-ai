from __future__ import annotations

import argparse
import os
import shlex
import sys
import time
from pathlib import Path
from typing import Any

from . import __version__
from .core import (
    NarrowError,
    Store,
    accept_criterion,
    changed_paths,
    classify_paths,
    create_task,
    finish_task,
    find_repo_root,
    init_project,
    load_config,
    make_handoff,
    record_note,
    redact,
    run_git,
    save_check_run,
    snapshot_hash,
    unsafe_workspace_links,
    task_workspace,
)
from .supervisor import run_agent, run_verification_command
from .drive import drive_task


def _find_root() -> Path:
    current_repo = find_repo_root()
    state = current_repo / ".narrow" / "state.sqlite3"
    if state.exists():
        return current_repo
    raise NarrowError("NARROW is not initialized in this repository. Run commands from the original checkout after `narrow init`.")


def _store() -> Store:
    return Store(_find_root())


def _task_label(task: dict[str, Any]) -> str:
    return f"{task['title']} [{task['id']}] — {task['status']}"


def cmd_init(_: argparse.Namespace) -> int:
    root = find_repo_root()
    path = init_project(root)
    print(f"Initialized NARROW in {root}")
    print(f"Config: {path}")
    print("No agent was launched, no network request was made, and no tracked project file was changed.")
    print("Edit .narrow/config.json to add project-specific, non-destructive verification commands.")
    return 0


def cmd_start(args: argparse.Namespace) -> int:
    root = find_repo_root()
    store = Store(root)
    task = create_task(store, args.title, args.goal, args.allow, args.deny, args.accept)
    print("Task created in an isolated repository copy.")
    print(f"Task: {_task_label(task)}")
    print(f"Isolated workspace: {task['worktree']}")
    print(f"Branch: {task['branch']}")
    print(f"Task brief: {Path(task['worktree']) / 'NARROW_TASK.md'}")
    print("\nRun the agent from the original checkout with:")
    print("  narrow run -- claude")
    print("  narrow run -- codex")
    print("The command is illustrative; use an installed agent CLI you trust.")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    print(_task_label(task))
    print(f"Goal: {task['goal']}")
    print(f"Base: {task['base_sha']}")
    print(f"Branch: {task['branch']}")
    print(f"Isolated workspace: {task['worktree']}")
    print(f"Allowed: {', '.join(task['allowed'])}")
    print(f"Denied: {', '.join(task['denied']) or '(none)'}")
    print("Acceptance:")
    for index, item in enumerate(task["acceptance"], 1):
        flag = "x" if item["accepted"] else " "
        print(f"  [{flag}] {index}. {item['text']}")
    events = store.events(task["id"], limit=10000)
    print(f"Recorded events: {len(events)}")
    return 0


def _agent_command(args: argparse.Namespace) -> list[str]:
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    return command


def cmd_run(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    return run_agent(store, task["id"], _agent_command(args), resume=False)


def cmd_drive(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    return drive_task(
        store,
        task["id"],
        args.agent,
        max_attempts=args.max_attempts,
        yes_checks=args.yes_checks,
    )


def cmd_resume(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    command = _agent_command(args)
    if not command:
        print(make_handoff(store, task["id"]))
        return 0
    return run_agent(store, task["id"], command, resume=True)


def cmd_inspect(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    workspace = task_workspace(task)
    paths = changed_paths(workspace)
    result = classify_paths(paths, task["allowed"], task["denied"])
    unsafe_links = unsafe_workspace_links(workspace)
    print(f"Task: {_task_label(task)}")
    print(f"Changed files: {len(paths)}")
    if unsafe_links:
        print("\nUNSAFE WORKSPACE LINKS")
        for item in unsafe_links:
            print(f"  {item}")
    for category in ("allowed", "outside", "denied"):
        print(f"\n{category.upper()} ({len(result[category])})")
        for path in result[category]:
            print(f"  {path}")
    try:
        head = run_git(workspace, ["rev-parse", "HEAD"])
        if head != task["base_sha"]:
            print("\nWARNING: task branch HEAD changed; agent may have committed or switched state.")
    except NarrowError as exc:
        print(f"\nWARNING: could not inspect task HEAD: {exc}")
    store.add_event(task["id"], "INSPECTION", result)
    return 2 if result["outside"] or result["denied"] or unsafe_links else 0


def cmd_note(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    record_note(store, task["id"], "NOTE", args.text)
    print("Note saved to the local task journal.")
    return 0


def cmd_decision(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    record_note(store, task["id"], "DECISION", args.text)
    print("Decision saved to the local task journal.")
    return 0


def cmd_handoff(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    content = make_handoff(store, task["id"])
    if args.output:
        output = Path(args.output).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(content, encoding="utf-8")
        print(f"Handoff written to {output}")
    else:
        print(content)
    return 0


def cmd_accept(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    accept_criterion(store, task["id"], args.criterion, args.evidence)
    print(f"Acceptance criterion {args.criterion} recorded as human-confirmed.")
    return 0


def _confirm(command: list[str], yes: bool) -> bool:
    print("Verification command:")
    print("  " + shlex.join(command))
    print("This executes the configured command inside the isolated task workspace with your user permissions.")
    if yes:
        return True
    try:
        answer = input("Run this check? [y/N] ").strip().lower()
    except EOFError:
        return False
    return answer in {"y", "yes"}


def cmd_verify(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    config = load_config(store.root)
    checks = config.get("checks", {})
    if args.check not in checks:
        available = ", ".join(checks) or "(none configured)"
        raise NarrowError(f"Unknown check '{args.check}'. Configured checks: {available}. Edit .narrow/config.json first.")
    spec = checks[args.check]
    if not isinstance(spec, dict):
        raise NarrowError(f"Check '{args.check}' configuration must be an object.")
    command = spec.get("command")
    if not isinstance(command, list) or not command or not all(isinstance(part, str) and part and "\x00" not in part for part in command):
        raise NarrowError(f"Check '{args.check}' must define a non-empty argv array. Shell strings are not supported.")
    if not _confirm(command, args.yes):
        print("Cancelled. No verification command was run.")
        return 1
    workspace = task_workspace(task)
    unsafe_before = unsafe_workspace_links(workspace)
    if unsafe_before:
        raise NarrowError("NARROW refuses to run verification while unsafe symlinks or hard-linked files exist: " + ", ".join(unsafe_before[:20]))
    before = snapshot_hash(workspace)
    try:
        raw_timeout = spec.get("timeout_seconds", 300)
        if not isinstance(raw_timeout, int) or isinstance(raw_timeout, bool) or raw_timeout < 1:
            raise ValueError("timeout_seconds must be a positive integer")
        timeout = min(raw_timeout, 24 * 60 * 60)
    except (TypeError, ValueError, OverflowError) as exc:
        raise NarrowError(f"Check '{args.check}' has an invalid timeout_seconds value.") from exc
    started = time.monotonic()
    verify_env = os.environ.copy()
    verify_env["PYTHONDONTWRITEBYTECODE"] = "1"
    exit_code, output = run_verification_command(
        command, cwd=workspace, env=verify_env, timeout=timeout
    )
    duration = int((time.monotonic() - started) * 1000)
    after = snapshot_hash(workspace)
    unsafe_after = unsafe_workspace_links(workspace)
    if unsafe_after:
        exit_code = 125
        output += "\nNARROW: verification created unsafe symlinks or hard-linked files: " + ", ".join(unsafe_after[:20])
    if before != after and exit_code == 0:
        exit_code = 125
        output += "\nNARROW: verification changed the workspace. The result is not accepted; restore generated artifacts or add them to Git ignore, then rerun."
    save_check_run(store, task["id"], args.check, command, after, exit_code, duration, output)
    print((redact(output) or "(no output)")[-6000:])
    print(f"\nCheck {'PASSED' if exit_code == 0 else 'FAILED'} (exit {exit_code}; {duration} ms).")
    return 0 if exit_code == 0 else 1


def cmd_finish(args: argparse.Namespace) -> int:
    store = _store()
    task = store.get_task(args.task)
    success, problems = finish_task(store, task["id"])
    if success:
        print("VERIFIED_COMPLETE")
        print("All configured checks passed for the current workspace snapshot, every acceptance criterion was human-confirmed, and the original checkout remained unchanged.")
        print("Review the isolated diff before manually integrating it. NARROW has not merged, committed, or pushed anything.")
        return 0
    print("NEEDS_REVIEW — NARROW will not claim completion.")
    for item in problems:
        print(f"- {item}")
    return 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="narrow",
        description="Safety-first task continuity and completion supervision for AI agents.",
    )
    parser.add_argument("--version", action="version", version=f"NARROW {__version__}")
    sub = parser.add_subparsers(dest="subcommand", required=True)

    sub.add_parser("init", help="Initialize local NARROW metadata and configuration.").set_defaults(func=cmd_init)

    start = sub.add_parser("start", help="Create a task in an isolated repository copy.")
    start.add_argument("--title", required=True)
    start.add_argument("--goal", required=True)
    start.add_argument("--allow", action="append", default=[], help="Allowed path glob; repeat for multiple patterns.")
    start.add_argument("--deny", action="append", default=[], help="Denied path glob; repeat for multiple patterns.")
    start.add_argument("--accept", action="append", default=[], help="Acceptance criterion; repeat for multiple criteria.")
    start.set_defaults(func=cmd_start)

    run = sub.add_parser("run", help="Run an installed AI agent inside the isolated task workspace.")
    run.add_argument("--task")
    run.add_argument("command", nargs=argparse.REMAINDER, help="Agent command after --, e.g. -- claude")
    run.set_defaults(func=cmd_run)

    resume = sub.add_parser("resume", help="Rebuild compact task memory and optionally launch another agent session.")
    resume.add_argument("--task")
    resume.add_argument("command", nargs=argparse.REMAINDER, help="Optional agent command after --, e.g. -- codex")
    resume.set_defaults(func=cmd_resume)

    drive = sub.add_parser(
        "drive",
        help="Run a bounded agent → checks → repair loop using a configured agent adapter.",
    )
    drive.add_argument("--agent", required=True, help="Name of an agent entry in .narrow/config.json.")
    drive.add_argument("--task")
    drive.add_argument("--max-attempts", type=int, help="Repair budget (1–5); defaults to max_repair_attempts.")
    drive.add_argument("--yes-checks", action="store_true", help="Approve configured checks without prompting; use only after reviewing them.")
    drive.set_defaults(func=cmd_drive)

    status = sub.add_parser("status", help="Show current task, constraints, and acceptance state.")
    status.add_argument("--task")
    status.set_defaults(func=cmd_status)

    inspect = sub.add_parser("inspect", help="Classify changed paths against the task's scope.")
    inspect.add_argument("--task")
    inspect.set_defaults(func=cmd_inspect)

    note = sub.add_parser("note", help="Append a note to the local task memory.")
    note.add_argument("text")
    note.add_argument("--task")
    note.set_defaults(func=cmd_note)

    decision = sub.add_parser("decision", help="Append a decision to the local task memory.")
    decision.add_argument("text")
    decision.add_argument("--task")
    decision.set_defaults(func=cmd_decision)

    handoff = sub.add_parser("handoff", help="Generate a compact, resumable task handoff.")
    handoff.add_argument("--task")
    handoff.add_argument("--output", help="Optional file path; omit to print the handoff.")
    handoff.set_defaults(func=cmd_handoff)

    accept = sub.add_parser("accept", help="Human-confirm one acceptance criterion with evidence.")
    accept.add_argument("--criterion", type=int, required=True)
    accept.add_argument("--evidence", required=True)
    accept.add_argument("--task")
    accept.set_defaults(func=cmd_accept)

    verify = sub.add_parser("verify", help="Run one explicitly configured verification command.")
    verify.add_argument("--check", required=True)
    verify.add_argument("--task")
    verify.add_argument("--yes", action="store_true", help="Skip interactive confirmation; use only for trusted checks.")
    verify.set_defaults(func=cmd_verify)

    finish = sub.add_parser("finish", help="Mark verified completion only when all gates pass.")
    finish.add_argument("--task")
    finish.set_defaults(func=cmd_finish)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except NarrowError as exc:
        print(f"NARROW: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted. The isolated workspace and task journal were preserved.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
