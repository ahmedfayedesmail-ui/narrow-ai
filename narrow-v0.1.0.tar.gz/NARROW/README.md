# NARROW

**AI can start the work. NARROW helps make sure the work is finished safely.**

NARROW is an open-source, local-first task continuity and safety supervisor for AI agents. It combines three ideas in one workflow:

1. **Scope protection** — make the task boundaries explicit and watch repository changes while an agent works.
2. **Secondhand memory** — keep a compact, append-only record of the goal, decisions, progress, and verification so a new session or a different agent can resume without reconstructing the whole conversation.
3. **Completion gates** — distinguish “the agent stopped” from “the task is verified.” A task is only marked `VERIFIED_COMPLETE` after configured checks pass on the current exact workspace snapshot and a human confirms every acceptance criterion.

NARROW is not another model, does not require an API key, and does not send your source code to a NARROW server. It wraps an agent CLI you already use.

> **Important safety boundary:** A separate full Git copy with its own Git metadata and no configured remotes keeps ordinary repository operations away from your original checkout. It is not an operating-system sandbox. Commands launched by an agent still run with your user permissions and may access files, services, or network resources available to you. Keep the agent's own approval controls enabled. Do not use NARROW as a substitute for container/VM isolation when the task or agent is untrusted.

## What works in v0.1.0

- Creates a separate Git branch and workspace for each task.
- Refuses to start if the original Git working tree has uncommitted changes.
- Requires explicit allowed-path patterns and acceptance criteria.
- Writes a task brief into the isolated workspace.
- Can launch any installed agent CLI without a shell (`shell=False`).
- Monitors tracked, untracked, and ignored paths, explicit deny patterns, the original checkout, branch HEAD, run duration, and changed-file count; it also performs a final safety scan when the agent exits quickly.
- Refuses task copies containing symlinks that resolve outside the workspace or hard-linked regular files, and monitors for their creation during a run.
- Runs NARROW-managed Git checks with inherited Git redirection variables and global/system configuration disabled.
- Stops the agent or verification process group on observed violations/timeouts (best effort; detached or escaped processes may outlive the wrapper).
- Fingerprints NARROW-owned task, handoff, and prompt files during a run; restores the task brief from the local task record before a later run if it was altered.
- Keeps task notes and decisions in a local SQLite event journal.
- Generates a compact handoff for a new session or a different provider.
- Runs explicitly configured verification commands as argument arrays, after human confirmation.
- Offers a bounded `drive` cycle: run a configured agent command, execute the approved checks, preserve failure output in the handoff, and request a scoped repair for up to five attempts.
- Stops automatic repair if verification itself changes the workspace.
- Leaves successful work at `READY_FOR_REVIEW`; a human must inspect it and confirm every acceptance criterion before `finish` can mark it verified.
- Does not commit, merge, push, publish, deploy, or modify the original checkout by design.

## What v0.1 does not claim

- It does not understand every provider's private conversation state or tool-call stream. v0.1 uses a user-configured command adapter, not provider-native Claude/Codex integrations.
- Its repair cycle is bounded and check-driven; it does not guarantee that a model can diagnose or fix every failure.
- It does not guarantee that an agent obeys `NARROW_TASK.md`.
- It cannot prevent an agent command from modifying files outside the workspace using absolute paths, subprocesses, network tools, or other external tools. Workspace polling is not an OS security boundary and cannot eliminate time-of-check/time-of-use races.
- It cannot prove semantic correctness from a green test suite alone.
- It does not automatically integrate task changes into your original branch.

These are intentional boundaries, not hidden capabilities. Provider adapters, richer verification, and stronger sandbox integrations are roadmap work.

## Requirements

- Python 3.11+
- Git 2.30+
- An AI agent CLI of your choice, installed and authenticated separately

No runtime Python dependencies are required. The initial QA run was performed on Linux with Python 3.13 and Git 2.47; Windows and macOS behavior has not yet been validated in CI by maintainers.

## Install from source

```bash
python -m venv .venv
# macOS / Linux
. .venv/bin/activate
# Windows PowerShell
.venv\Scripts\Activate.ps1

python -m pip install -e .
```

## Quick start

Run these commands from the root of a Git repository:

```bash
narrow init
narrow start \
  --title "Fix mobile navigation overflow" \
  --goal "Fix the mobile navigation overflow without changing desktop behavior." \
  --allow "src/navigation/**" \
  --allow "tests/navigation/**" \
  --deny "src/auth/**" \
  --accept "The navigation no longer overflows at the supported mobile widths." \
  --accept "Desktop navigation behavior remains unchanged."
```

NARROW creates a new isolated workspace outside the project directory and prints its path. It does not move or modify your original checkout.

Start an agent from the original checkout:

```bash
narrow run -- claude
# or
narrow run -- codex
```

The selected CLI must be installed and available on `PATH`. When the agent opens, ask it to read `NARROW_TASK.md` before editing. Its task environment includes `NARROW_TASK_ID`, `NARROW_TASK_FILE`, and `NARROW_WORKTREE` (the isolated workspace path).

When a session ends or needs to switch providers:

```bash
narrow note "The layout fix is in place; mobile Safari still needs checking."
narrow decision "Keep the existing navigation component; do not introduce another dependency."
narrow handoff
narrow resume -- codex
```

The handoff is a compact operational memory, not a transcript. It includes the task contract, changed paths, acceptance state, recorded decisions, recent verification results, and the latest failed-check output when available.

`narrow resume` writes `NARROW_HANDOFF.md` in the isolated workspace, exports its path as `NARROW_HANDOFF_FILE`, and launches the next CLI. Ask the new agent to read both `NARROW_TASK.md` and `NARROW_HANDOFF.md` before continuing. With no command, `narrow resume` prints the handoff to the terminal.

Inspect the work and scope report:

```bash
narrow status
narrow inspect
```

## Configure the bounded `drive` engine

`drive` requires an agent command that accepts the path to a prompt file. Configure that command explicitly; NARROW does not guess provider-specific CLI syntax. For example, adapt the argument names to a wrapper you have tested:

```json
{
  "agents": {
    "my-agent": {
      "command": ["python", "tools/my_agent_adapter.py", "{prompt_file}"]
    }
  },
  "max_repair_attempts": 3
}
```

After also configuring at least one trusted check in `checks`, run:

```bash
narrow drive --agent my-agent
```

NARROW shows every configured check and asks once before the drive session begins. On failure it writes a fresh prompt containing the handoff and failure details, then starts another bounded attempt. The default budget is three attempts and the hard maximum is five. `--yes-checks` skips the check confirmation only; use it only after reviewing every command. A passing drive ends at `READY_FOR_REVIEW`, never `VERIFIED_COMPLETE`. Review the diff and test evidence, then confirm acceptance criteria and run `narrow finish`.

There are no provider-native Claude Code or Codex adapters in v0.1.0. The generic adapter contract is intentionally explicit so users do not have to grant NARROW hidden access to agent sessions or tokens.

## Configure verification before using `finish`

NARROW intentionally does not guess how your project should be tested. Edit `.narrow/config.json` and add commands that are appropriate for this repository. Commands must be JSON argument arrays; shell command strings and implicit shell expansion are not accepted.

Example for a Python project:

```json
{
  "schema_version": 1,
  "monitor_interval_seconds": 2,
  "max_run_seconds": 3600,
  "max_changed_files": 100,
  "stop_on_scope_violation": true,
  "max_repair_attempts": 3,
  "agents": {},
  "checks": {
    "unit": {
      "command": ["python", "-m", "unittest", "discover", "-s", "tests"],
      "timeout_seconds": 300,
      "description": "Run unit tests"
    }
  }
}
```

Run each configured check explicitly:

```bash
narrow verify --check unit
```

NARROW prints the exact command and asks for confirmation. Use `--yes` only for commands you have reviewed and trust.

After reviewing the changed files and the test output, confirm acceptance criteria one by one:

```bash
narrow accept --criterion 1 --evidence "Checked the navigation at 360px, 390px, and 430px."
narrow accept --criterion 2 --evidence "Compared the desktop layout against the original behavior."
narrow finish
```

If any file is outside the allowed scope, a check fails, the workspace changes after checks, the task branch changes, or the original checkout is no longer clean, NARROW refuses to claim verified completion.

## Useful commands

| Command | Purpose |
|---|---|
| `narrow init` | Initialize local state and config |
| `narrow start ...` | Create an isolated task workspace |
| `narrow run -- <agent>` | Launch an agent under the scope monitor |
| `narrow drive --agent <name>` | Run a bounded agent → checks → repair cycle |
| `narrow status` | Show task state and acceptance criteria |
| `narrow inspect` | Classify changed paths |
| `narrow note "..."` | Save task knowledge |
| `narrow decision "..."` | Save an explicit decision |
| `narrow handoff` | Export compact continuity memory |
| `narrow resume -- <agent>` | Prepare handoff and launch a new session |
| `narrow verify --check <name>` | Run one configured check after confirmation |
| `narrow accept ...` | Human-confirm an acceptance criterion |
| `narrow finish` | Apply the verified-completion gate |

## Data and privacy

All NARROW task state is stored in `.narrow/` inside the original repository; the directory is added to that repository's local Git exclude file, not its tracked `.gitignore`. Isolated repository copies are stored in the user's local cache directory; configured remotes are removed from each copy. NARROW does not make network requests. Notes and event payloads are locally redacted for several common credential patterns, but redaction is not perfect: never paste secrets into task notes or acceptance evidence.

The AI agent itself may have network access and may process project data according to that provider's own terms and settings. NARROW does not change that behavior.

## Safety-first defaults

- Clean original checkout required before a task starts.
- Explicit file allowlist required.
- Human approval before configured verification commands run; captured check output is bounded to the last 64 KiB while streaming, to avoid unbounded in-memory log growth.
- No shell interpolation by NARROW for agent or verification commands.
- No automatic commits, merges, pushes, deployments, or external writes.
- No automatic completion based solely on an agent's “Done” message.
- No global or project dependencies are installed by `narrow init`.
- NARROW-managed Git operations disable system/global Git config, Git environment redirection, and the fsmonitor hook; initial checkout skips Git LFS smudge downloads, so LFS objects may need manual provisioning. These settings do not sandbox arbitrary commands launched by an agent.

See [docs/SAFETY_MODEL.md](docs/SAFETY_MODEL.md), [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md), [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), and [docs/QA-RESULTS-v0.1.0.md](docs/QA-RESULTS-v0.1.0.md) for the current validation boundary.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Please include tests for every safety-related change. A change that weakens a fail-closed behavior requires an explicit design discussion and threat-model update.

## License

MIT. See [LICENSE](LICENSE).
